# Għerf: setup (one time, about 10 minutes)

## 1. Put the files on GitHub
1. Sign in at github.com and create a new **private** repository called `gherf`.
2. Tap **Add file → Upload files** and upload everything from this zip's top level:
   index.html, sw.js, manifest.webmanifest, netlify.toml, icon-192.png, icon-512.png, icon-maskable-512.png, apple-touch-icon.png
3. Tap **Add file → Create new file**. In the name box type exactly
   `netlify/edge-functions/ai.js`
   then paste in the contents of that file from the zip and commit.

## 2. Connect Netlify
1. In Netlify: **Add new site → Import an existing project → GitHub** and pick `gherf`.
2. Leave build settings empty (publish directory `.`), and deploy.
3. Site configuration → **Environment variables → Add variable**
   Key: `AI_API_KEY`  Value: your secret key (from console.anthropic.com → API keys)
4. **Deploys → Trigger deploy** once so the key is picked up.
5. Optional: Domain management → set your site name (e.g. gherf.netlify.app).

## 3. Protect your bill
In console.anthropic.com → Settings → Limits, set a monthly spend limit.

## Updating later
Replace the changed files in GitHub (Upload files, same names). Netlify publishes in about a minute,
and every installed copy of the app updates itself the next time it is opened.
