// Għerf knowledge service: keeps the API key on the server and streams answers to the app.
// Set the environment variable AI_API_KEY in Netlify → Site configuration → Environment variables.
const hits = new Map(); // simple per-visitor limit (per edge instance)
const LIMIT = 60, WINDOW_MS = 10 * 60 * 1000;

export default async (req, context) => {
  if (req.method !== "POST") return new Response("Not found", { status: 404 });

  const origin = req.headers.get("origin");
  const host = new URL(req.url).host;
  if (origin) { try { if (new URL(origin).host !== host) return new Response("Forbidden", { status: 403 }); } catch { return new Response("Forbidden", { status: 403 }); } }

  const ip = context.ip || "anon", now = Date.now();
  const h = (hits.get(ip) || []).filter(t => now - t < WINDOW_MS);
  if (h.length >= LIMIT) return new Response("Slow down", { status: 429 });
  h.push(now); hits.set(ip, h);

  const key = Netlify.env.get("AI_API_KEY");
  if (!key) return new Response("Service not configured", { status: 503 });

  let body;
  try { body = await req.json(); } catch { return new Response("Bad request", { status: 400 }); }
  const messages = (Array.isArray(body.messages) ? body.messages : []).slice(-12)
    .filter(m => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map(m => ({ role: m.role, content: m.content.slice(0, 30000) }));
  if (!messages.length || messages[messages.length - 1].role !== "user") return new Response("Bad request", { status: 400 });

  const model = body.tier === "quick" ? "claude-haiku-5-5" : "claude-sonnet-5-5";
  const upstream = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model, max_tokens: 8000, stream: true, messages }),
  });
  if (!upstream.ok) return new Response("Service error", { status: upstream.status === 429 ? 429 : 502 });

  return new Response(upstream.body, { headers: { "content-type": "text/event-stream", "cache-control": "no-store" } });
};

export const config = { path: "/api/ai" };
